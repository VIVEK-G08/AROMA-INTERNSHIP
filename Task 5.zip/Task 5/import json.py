import json
import random

# Load quiz questions from a JSON file
def load_questions(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

# Display a question and get the user's answer
def ask_question(question):
    print(question["question"])
    for i, option in enumerate(question["options"], 1):
        print(f"{i}. {option}")
    user_answer = input("Your answer (enter the number): ").strip()
    return user_answer

# Evaluate the user's answer
def evaluate_answer(question, user_answer):
    correct_answer = question["answer"]
    options = question["options"]
    try:
        user_choice = options[int(user_answer) - 1]
        return user_choice == correct_answer
    except (IndexError, ValueError):
        return False

# Main quiz function
def run_quiz(questions):
    score = 0
    total_questions = len(questions)
    random.shuffle(questions)  # Shuffle questions for variety

    for question in questions:
        user_answer = ask_question(question)
        if evaluate_answer(question, user_answer):
            print("Correct!\n")
            score += 1
        else:
            print(f"Wrong! The correct answer is: {question['answer']}\n")

    print(f"Quiz ended! Your score: {score}/{total_questions}")

# Entry point
if __name__ == "__main__":
    questions = load_questions("quiz_data.json")
    print("Welcome to the Dynamic Quiz App!\n")
    run_quiz(questions)