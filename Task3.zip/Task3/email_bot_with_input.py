import smtplib
import imaplib
import email
from email.mime.text import MIMEText
from getpass import getpass

# Function to send email
def send_email(user_email, user_password, to_email, subject, body):
    with smtplib.SMTP("smtp.gmail.com", 587) as smtp:
        smtp.starttls()  # Upgrade to a secure connection
        smtp.login(user_email, user_password)  # Login to the user's email account
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = user_email
        msg["To"] = to_email
        smtp.sendmail(user_email, to_email, msg.as_string())  # Send the email
        print(f"Replied to {to_email}")

# Function to check and reply to unread emails
def check_and_reply(user_email, user_password):
    # Connect to the IMAP server
    with imaplib.IMAP4_SSL("imap.gmail.com") as imap:
        imap.login(user_email, user_password)
        imap.select("inbox")  # Select the inbox folder

        # Search for unread emails
        status, messages = imap.search(None, "UNSEEN")
        email_ids = messages[0].split()

        if not email_ids:
            print("No unread emails found.")
            return

        for email_id in email_ids:
            # Fetch the email by ID
            status, msg_data = imap.fetch(email_id, "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    # Parse the email content
                    msg = email.message_from_bytes(response_part[1])
                    sender = email.utils.parseaddr(msg["From"])[1]
                    subject = msg["Subject"]

                    # Prepare and send the reply
                    reply_body = "Thank you for your email. I will get back to you shortly."
                    send_email(user_email, user_password, sender, f"Re: {subject}", reply_body)

                    # Mark the email as read
                    imap.store(email_id, "+FLAGS", "\\Seen")

# Main function
if __name__ == "__main__":
    # Prompt the user for email credentials
    user_email = input("Enter your email address: ")
    user_password = getpass("Enter your email password (hidden): ")

    try:
        # Call the function to check and reply to emails
        check_and_reply(user_email, user_password)
    except Exception as e:
        print(f"An error occurred: {e}")
