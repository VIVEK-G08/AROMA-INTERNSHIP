class EmailValidator:
    """
    A comprehensive email validation tool that checks various aspects of email addresses
    and provides detailed feedback on validation failures.
    """
    
    def __init__(self):
        self.max_local_length = 64
        self.max_domain_length = 255
        self.max_total_length = 254
        
        # Common disposable email domains
        self.disposable_domains = {
            'tempmail.com', 'throwawaymail.com', 'tmpmail.org',
            'guerrillamail.com', '10minutemail.com'
        }
        
        # Common typos in popular email domains
        self.common_typos = {
            'gmial.com': 'gmail.com',
            'gmal.com': 'gmail.com',
            'gmil.com': 'gmail.com',
            'hotmal.com': 'hotmail.com',
            'hotmil.com': 'hotmail.com',
            'yaho.com': 'yahoo.com',
            'yahooo.com': 'yahoo.com'
        }
    
    def validate_email(self, email: str) -> dict:
        """
        Validates an email address and returns a dictionary with validation results
        and suggestions for improvement.
        
        Args:
            email: The email address to validate
            
        Returns:
            dict: Validation results including:
                - is_valid: Boolean indicating if email is valid
                - errors: List of validation errors
                - warnings: List of potential issues
                - suggestions: List of improvement suggestions
        """
        result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'suggestions': []
        }
        
        # Basic checks
        if not email:
            result['is_valid'] = False
            result['errors'].append('Email address cannot be empty')
            return result
        
        # Check total length
        if len(email) > self.max_total_length:
            result['is_valid'] = False
            result['errors'].append(
                f'Email exceeds maximum length of {self.max_total_length} characters'
            )
        
        # Split email into local and domain parts
        try:
            local_part, domain = email.split('@')
        except ValueError:
            result['is_valid'] = False
            result['errors'].append('Email must contain exactly one @ symbol')
            return result
        
        # Validate local part
        self._validate_local_part(local_part, result)
        
        # Validate domain
        self._validate_domain(domain, result)
        
        # Check for common typos
        self._check_common_typos(domain, result)
        
        # Check for disposable email domains
        if domain.lower() in self.disposable_domains:
            result['warnings'].append(
                'This appears to be a disposable email address'
            )
        
        return result
    
    def _validate_local_part(self, local_part: str, result: dict) -> None:
        """Validates the local part (before @) of the email address."""
        
        if not local_part:
            result['is_valid'] = False
            result['errors'].append('Local part cannot be empty')
            return
        
        if len(local_part) > self.max_local_length:
            result['is_valid'] = False
            result['errors'].append(
                f'Local part exceeds maximum length of {self.max_local_length} characters'
            )
        
        # Check for invalid characters
        invalid_chars = set('"(),:;<>[]\\')
        found_invalid = set(local_part) & invalid_chars
        if found_invalid:
            result['is_valid'] = False
            result['errors'].append(
                f'Local part contains invalid characters: {", ".join(found_invalid)}'
            )
        
        # Check for leading/trailing periods
        if local_part.startswith('.') or local_part.endswith('.'):
            result['is_valid'] = False
            result['errors'].append(
                'Local part cannot start or end with a period'
            )
        
        # Check for consecutive periods
        if '..' in local_part:
            result['is_valid'] = False
            result['errors'].append(
                'Local part cannot contain consecutive periods'
            )
    
    def _validate_domain(self, domain: str, result: dict) -> None:
        """Validates the domain part (after @) of the email address."""
        
        if not domain:
            result['is_valid'] = False
            result['errors'].append('Domain cannot be empty')
            return
        
        if len(domain) > self.max_domain_length:
            result['is_valid'] = False
            result['errors'].append(
                f'Domain exceeds maximum length of {self.max_domain_length} characters'
            )
        
        # Domain must have at least one period
        if '.' not in domain:
            result['is_valid'] = False
            result['errors'].append('Domain must contain at least one period')
        
        # Check for invalid characters
        if not all(c.isalnum() or c in '.-' for c in domain):
            result['is_valid'] = False
            result['errors'].append(
                'Domain can only contain letters, numbers, periods, and hyphens'
            )
        
        # Check for leading/trailing periods or hyphens
        if domain.startswith('.') or domain.startswith('-') or \
           domain.endswith('.') or domain.endswith('-'):
            result['is_valid'] = False
            result['errors'].append(
                'Domain cannot start or end with a period or hyphen'
            )
        
        # Check for consecutive periods
        if '..' in domain:
            result['is_valid'] = False
            result['errors'].append('Domain cannot contain consecutive periods')
    
    def _check_common_typos(self, domain: str, result: dict) -> None:
        """Checks for common typos in email domains and suggests corrections."""
        
        lower_domain = domain.lower()
        if lower_domain in self.common_typos:
            result['warnings'].append(
                f'Possible typo in domain: Did you mean {self.common_typos[lower_domain]}?'
            )