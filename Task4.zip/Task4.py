import imaplib
import smtplib
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time

# Email credentials
EMAIL = 'your_email@gmail.com'
PASSWORD = 'your_app_password'
IMAP_SERVER = 'imap.gmail.com'
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587

# Function to read emails
def read_emails():
    # Connect to the IMAP server
    mail = imaplib.IMAP4_SSL(IMAP_SERVER)
    mail.login(EMAIL, PASSWORD)
    mail.select('inbox')  # Select the inbox

    # Search for unread emails
    status, messages = mail.search(None, 'UNSEEN')
    if status == 'OK':
        email_ids = messages[0].split()
        for e_id in email_ids:
            # Fetch the email
            status, msg_data = mail.fetch(e_id, '(RFC822)')
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])
                    subject = msg['subject']
                    from_ = msg['from']
                    print(f"New email from: {from_}, Subject: {subject}")

                    # Parse the email content
                    if msg.is_multipart():
                        for part in msg.walk():
                            content_type = part.get_content_type()
                            if content_type == 'text/plain':
                                body = part.get_payload(decode=True).decode()
                                print(f"Body: {body}")
                    else:
                        body = msg.get_payload(decode=True).decode()
                        print(f"Body: {body}")

                    # Send an automated reply
                    send_auto_reply(from_, subject)

    # Close the connection
    mail.close()
    mail.logout()

# Function to send automated replies
def send_auto_reply(to, subject):
    msg = MIMEMultipart()
    msg['From'] = EMAIL
    msg['To'] = to
    msg['Subject'] = f"Re: {subject}"

    # Customize your reply message
    body = "Thank you for your email. This is an automated reply. I will get back to you soon."
    msg.attach(MIMEText(body, 'plain'))

    # Send the email
    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(EMAIL, PASSWORD)
        server.sendmail(EMAIL, to, msg.as_string())
        print(f"Sent auto-reply to: {to}")

# Main loop to check emails periodically
def main():
    while True:
        print("Checking for new emails...")
        read_emails()
        time.sleep(300)  # Check every 5 minutes

if __name__ == '__main__':
    main()