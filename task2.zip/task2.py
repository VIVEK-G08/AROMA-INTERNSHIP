import tkinter as tk
from tkinter import messagebox
import json
import random
import time

class QuizApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Quiz Application")
        self.root.geometry("800x600")
        
        # Quiz data
        self.questions = [
            {
                "question": "What is the capital of France?",
                "options": ["London", "Berlin", "Paris", "Madrid"],
                "correct": 2
            },
            {
                "question": "Which planet is known as the Red Planet?",
                "options": ["Jupiter", "Mars", "Venus", "Saturn"],
                "correct": 1
            },
            {
                "question": "What is 2 + 2 × 3?",
                "options": ["12", "10", "8", "6"],
                "correct": 3
            },
            {
                "question": "Who painted the Mona Lisa?",
                "options": ["Van Gogh", "Da Vinci", "Picasso", "Rembrandt"],
                "correct": 1
            },
            {
                "question": "What is the largest mammal?",
                "options": ["African Elephant", "Blue Whale", "Giraffe", "Hippopotamus"],
                "correct": 1
            }
        ]
        
        # Quiz state
        self.current_question = 0
        self.score = 0
        self.time_left = 30  # seconds per question
        self.timer_running = False
        
        # Create GUI elements
        self.create_widgets()
        self.load_question()
        
    def create_widgets(self):
        # Style configuration
        self.root.configure(bg='#f0f0f0')
        
        # Timer label
        self.timer_label = tk.Label(
            self.root,
            text="Time Left: 30",
            font=("Arial", 16),
            bg='#f0f0f0'
        )
        self.timer_label.pack(pady=10)
        
        # Question counter
        self.counter_label = tk.Label(
            self.root,
            text="Question 1/5",
            font=("Arial", 14),
            bg='#f0f0f0'
        )
        self.counter_label.pack(pady=5)
        
        # Score display
        self.score_label = tk.Label(
            self.root,
            text="Score: 0",
            font=("Arial", 14),
            bg='#f0f0f0'
        )
        self.score_label.pack(pady=5)
        
        # Question display
        self.question_frame = tk.Frame(self.root, bg='#f0f0f0')
        self.question_frame.pack(pady=20, padx=20, fill='both', expand=True)
        
        self.question_label = tk.Label(
            self.question_frame,
            wraplength=700,
            justify="center",
            font=("Arial", 12),
            bg='#f0f0f0'
        )
        self.question_label.pack(pady=20)
        
        # Options frame
        self.options_frame = tk.Frame(self.root, bg='#f0f0f0')
        self.options_frame.pack(pady=20, padx=20, fill='both', expand=True)
        
        # Option buttons
        self.option_buttons = []
        for i in range(4):
            btn = tk.Button(
                self.options_frame,
                font=("Arial", 11),
                width=40,
                command=lambda x=i: self.check_answer(x),
                bg='#e0e0e0',
                relief=tk.RAISED
            )
            btn.pack(pady=10)
            self.option_buttons.append(btn)
        
        # Next question button
        self.next_button = tk.Button(
            self.root,
            text="Next Question",
            command=self.next_question,
            state=tk.DISABLED,
            font=("Arial", 12),
            bg='#4CAF50',
            fg='white'
        )
        self.next_button.pack(pady=20)
        
    def load_question(self):
        """Load the current question and options"""
        question = self.questions[self.current_question]
        self.question_label.config(text=question["question"])
        
        for i, option in enumerate(question["options"]):
            self.option_buttons[i].config(
                text=option,
                state=tk.NORMAL,
                bg='#e0e0e0'
            )
        
        self.counter_label.config(
            text=f"Question {self.current_question + 1}/{len(self.questions)}"
        )
        self.score_label.config(text=f"Score: {self.score}")
        
        # Reset and start timer
        self.time_left = 30
        self.timer_running = True
        self.update_timer()
        
    def update_timer(self):
        """Update the timer display and check for timeout"""
        if self.timer_running and self.time_left > 0:
            self.timer_label.config(text=f"Time Left: {self.time_left}")
            self.time_left -= 1
            self.root.after(1000, self.update_timer)
        elif self.timer_running:
            self.timer_running = False
            self.handle_timeout()
            
    def handle_timeout(self):
        """Handle when time runs out for a question"""
        self.timer_running = False
        messagebox.showinfo("Time's Up!", "You ran out of time!")
        self.disable_options()
        self.next_button.config(state=tk.NORMAL)
        
    def check_answer(self, choice):
        """Check if the selected answer is correct"""
        self.timer_running = False
        correct_answer = self.questions[self.current_question]["correct"]
        
        # Highlight correct and incorrect answers
        for i, btn in enumerate(self.option_buttons):
            if i == correct_answer:
                btn.config(bg='#90EE90')  # Light green for correct
            elif i == choice:
                if choice == correct_answer:
                    btn.config(bg='#90EE90')  # Light green for correct
                else:
                    btn.config(bg='#FFB6C1')  # Light red for incorrect
        
        if choice == correct_answer:
            self.score += 1
            self.score_label.config(text=f"Score: {self.score}")
            messagebox.showinfo("Correct!", "That's the right answer!")
        else:
            messagebox.showinfo("Incorrect!", 
                              f"The correct answer was: {self.questions[self.current_question]['options'][correct_answer]}")
        
        self.disable_options()
        self.next_button.config(state=tk.NORMAL)
        
    def disable_options(self):
        """Disable all option buttons"""
        for button in self.option_buttons:
            button.config(state=tk.DISABLED)
            
    def next_question(self):
        """Move to the next question or end the quiz"""
        self.current_question += 1
        
        if self.current_question < len(self.questions):
            self.next_button.config(state=tk.DISABLED)
            self.load_question()
        else:
            self.show_final_results()
            
    def show_final_results(self):
        """Display the final quiz results"""
        percentage = (self.score / len(self.questions)) * 100
        message = f"Quiz completed!\n\nFinal Score: {self.score}/{len(self.questions)}\nPercentage: {percentage:.1f}%"
        
        if percentage >= 80:
            message += "\n\nExcellent performance!"
        elif percentage >= 60:
            message += "\n\nGood job!"
        else:
            message += "\n\nKeep practicing!"
            
        messagebox.showinfo("Quiz Results", message)
        
        # Ask if user wants to restart
        if messagebox.askyesno("Restart Quiz", "Would you like to try again?"):
            self.restart_quiz()
        else:
            self.root.quit()
            
    def restart_quiz(self):
        """Reset the quiz to start over"""
        self.current_question = 0
        self.score = 0
        random.shuffle(self.questions)  # Randomize question order
        self.next_button.config(state=tk.DISABLED)
        self.load_question()

if __name__ == "__main__":
    root = tk.Window()
    app = QuizApp(root)
    root.mainloop()